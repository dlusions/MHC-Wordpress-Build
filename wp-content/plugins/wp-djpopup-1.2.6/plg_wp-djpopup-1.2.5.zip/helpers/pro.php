<?php
/*--------------------------------------------------------------
 Copyright (C) dj-extensions.com
 Website: https://dj-extensions.com
 Support: contact@dj-extensions.com
---------------------------------------------------------------*/

class DJAccPro {
	public static function getVersion() {
		return 'dmVyc2lvbnBybw==';
	}
}